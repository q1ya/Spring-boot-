package com.example.service;
import com.example.entity.UserData;
import com.example.mapper.MainMapper;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.function.Function;

@Service
public class UserAuthService implements UserDetailsService {
    @Resource
    MainMapper mapper;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserData data = mapper.findUserByName(username);
        System.out.println(data);
        if(data == null) throw new BadCredentialsException("用户"+username+"用户名不存在");
        //if(data == null) throw new BadCredentialsException("用户"+username+"用户名不存在");上面那个异常可能有问题，使用这个
        return User
                .withUsername(data.getUsername())
                .password(data.getPassword())
                .roles(data.getRole())
                .build();
    }
}
