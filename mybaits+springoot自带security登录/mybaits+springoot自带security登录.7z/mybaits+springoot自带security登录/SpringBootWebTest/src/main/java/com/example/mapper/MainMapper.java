package com.example.mapper;

import com.example.entity.UserData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MainMapper {
    //@Select("select * from user where username = ${username}")使用$测试sql注入，发现这里不能使用$，可能框架限定死了#
    @Select("select * from user where username = #{username}")
    UserData findUserByName(String username);
}
