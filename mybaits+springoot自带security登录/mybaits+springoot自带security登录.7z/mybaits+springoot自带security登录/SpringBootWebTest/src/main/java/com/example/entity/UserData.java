package com.example.entity;
import lombok.Data;
@Data
public class UserData {
    int id;
    String username;
    String password;
    String role;
}
